---
id: "zh-十-一-COVID-19-01"
file: "style_zh"
section: "十 一 COVID-19"
lang: "zh"
source: "十-一-COVID-19.md"
---

十 一 COVID-19

 世界衞生組織採用的中文名稱為「2019 冠狀病毒病」。 
 一般用法上，「新型冠狀病毒肺炎」或「新冠肺炎」皆可。
